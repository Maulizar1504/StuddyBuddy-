<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Daftar - StudyBuddy</title>
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet"/>
</head>
<body class="splash-screen">
  <div class="auth-container">
    <div class="auth-header"> <img src="<?php echo e(asset('images/studybuddy_logo.png')); ?>" alt="StudyBuddy Logo" class="auth-logo">
      <h1>StudyBuddy</h1>
    </div>
    <h3>Selamat Datang</h3>
    <form id="signUpForm" method="POST" action="<?php echo e(route('register')); ?>">
      <?php echo csrf_field(); ?>
      <input type="text" id="username" name="username" placeholder="Nama Pengguna" required />
      <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="error-message"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      <input type="password" id="password" name="password" placeholder="Kata Sandi" required />
      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="error-message"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      <input type="password" id="password_confirmation" name="password_confirmation" placeholder="Konfirmasi Kata Sandi" required />
      <button type="submit">Daftar</button>
    </form>
    <p class="auth-link-text">Sudah punya akun? <a href="<?php echo e(route('login')); ?>">Masuk</a></p>
  </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\studybuddy\resources\views/auth/register.blade.php ENDPATH**/ ?>