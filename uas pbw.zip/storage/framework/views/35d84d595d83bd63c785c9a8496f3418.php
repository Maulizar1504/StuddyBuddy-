<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>Task Manager</title>
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

<?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="task-section">
  <h2 class="section-title">Tambah Tugas</h2>

  <?php if(session('success')): ?>
    <div class="alert-success"><?php echo e(session('success')); ?></div>
  <?php endif; ?>

  <?php if($errors->any()): ?>
    <div class="alert-danger">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>

  <form action="<?php echo e(route('tasks.store')); ?>" method="POST" class="task-form">
    <?php echo csrf_field(); ?>
    <input type="text" name="description" placeholder="Nama Tugas" required>
    <input type="date" name="deadline">
    <select name="priority" required>
      <option value="">Pilih Prioritas</option>
      <option value="now">Segera 🔥</option>
      <option value="rush">penting ⏰</option>
      <option value="plan">Siapkan 🧠</option>
    </select>
    <button type="submit" class="btn-add">Tambah Tugas</button>
  </form>
</div>

<div class="task-section">
  <h2 class="section-title">Tugas Aktif</h2>
  <ul class="task-list">
    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(!$task->completed): ?>
        <li class="task-item">
          <div class="task-content">
            <span class="task-description"><?php echo e($task->description); ?></span>
            <span class="task-details">
              Tenggat:
              <?php echo e($task->deadline ? \Carbon\Carbon::parse($task->deadline)->format('d M Y') : 'N/A'); ?>

              <br>
              Prioritas:
              <?php if($task->priority == 'now'): ?> Segera 🔥
              <?php elseif($task->priority == 'rush'): ?> penting ⏰
              <?php else: ?> Siapkan 🧠
              <?php endif; ?>
            </span>
          </div>
          <div class="task-actions">
            <form action="<?php echo e(route('tasks.toggle', $task)); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <button type="submit" class="btn-action btn-complete">
                <i class="fas fa-check"></i> Selesai
              </button>
            </form>
            <button type="button" class="btn-action btn-edit edit-task-btn"
              data-task-id="<?php echo e($task->id); ?>"
              data-description="<?php echo e($task->description); ?>"
              data-deadline="<?php echo e($task->deadline ? \Carbon\Carbon::parse($task->deadline)->format('Y-m-d') : ''); ?>"
              data-priority="<?php echo e($task->priority); ?>">
              <i class="fas fa-pen"></i> Edit
            </button>
            <form action="<?php echo e(route('tasks.destroy', $task)); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" class="btn-action btn-delete">
                <i class="fas fa-trash"></i> Hapus
              </button>
            </form>
          </div>
        </li>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>

<div class="task-section">
  <h2 class="section-title">Tugas Selesai</h2>
  <ul class="task-list">
    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($task->completed): ?>
        <li class="task-item completed-task">
          <div class="task-content">
            <span class="task-description"><?php echo e($task->description); ?></span>
            <span class="task-details">
              Tenggat:
              <?php echo e($task->deadline ? \Carbon\Carbon::parse($task->deadline)->format('d M Y') : 'N/A'); ?>

              <br>
              Prioritas:
              <?php if($task->priority == 'now'): ?> Segera 🔥
              <?php elseif($task->priority == 'rush'): ?> penting ⏰
              <?php else: ?> Siapkan 🧠
              <?php endif; ?>
            </span>
          </div>
          <div class="task-actions">
            <form action="<?php echo e(route('tasks.toggle', $task)); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <button type="submit" class="btn-action btn-uncomplete">
                <i class="fas fa-undo"></i> Uncomplete
              </button>
            </form>
            <form action="<?php echo e(route('tasks.destroy', $task)); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" class="btn-action btn-delete">
                <i class="fas fa-trash"></i> Delete
              </button>
            </form>
          </div>
        </li>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>


<div id="editTaskModal" class="modal">
  <div class="modal-content">
    <span class="close-button" onclick="closeModal('editTaskModal')">&times;</span>
    <h2>Edit Task</h2>
    <form id="editTaskForm" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
      <div class="form-group">
        <label for="edit_task_description">Nama Tugas:</label>
        <input type="text" id="edit_task_description" name="description" required>
      </div>
      <div class="form-group">
        <label for="edit_task_deadline">Tenggat:</label>
        <input type="date" id="edit_task_deadline" name="deadline">
      </div>
      <div class="form-group">
        <label for="edit_task_priority">Prioritas:</label>
        <select id="edit_task_priority" name="priority" required>
          <option value="now">Segera 🔥</option>
          <option value="rush">penting ⏰</option>
          <option value="plan">Siapkan 🧠</option>
        </select>
      </div>
      <button type="submit" class="btn btn-primary">Update Task</button>
    </form>
  </div>
</div>

<script>
function openModal(id) {
  document.getElementById(id).style.display = 'block';
}
function closeModal(id) {
  document.getElementById(id).style.display = 'none';
}
document.querySelectorAll('.edit-task-btn').forEach(button => {
  button.addEventListener('click', () => {
    const id = button.dataset.taskId;
    document.getElementById('edit_task_description').value = button.dataset.description;
    document.getElementById('edit_task_deadline').value = button.dataset.deadline;
    document.getElementById('edit_task_priority').value = button.dataset.priority;
    document.getElementById('editTaskForm').action = `/tasks/${id}`;
    openModal('editTaskModal');
  });
});
</script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\studybuddy\resources\views/tasks.blade.php ENDPATH**/ ?>