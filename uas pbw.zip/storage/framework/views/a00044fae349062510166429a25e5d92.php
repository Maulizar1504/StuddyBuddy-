<nav>
  <ul>
    
    <li><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
    <li><a href="<?php echo e(route('tasks.index')); ?>">Daftar Tugas</a></li>
    <li><a href="<?php echo e(route('planner.index')); ?>">Jadwal Kegiatan</a></li>
    <li><a href="<?php echo e(route('profile.index')); ?>">Akun Saya</a></li>
  </ul>
</nav><?php /**PATH C:\xampp\htdocs\studybuddy\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>