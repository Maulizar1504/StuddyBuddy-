<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>StudyBuddy Login</title>
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet"/>
</head>
<body class="splash-screen">
  <div class="auth-container">
    <div class="auth-header"> <img src="<?php echo e(asset('images/studybuddy_logo.png')); ?>" alt="StudyBuddy Logo" class="auth-logo">
      <h1>StudyBuddy</h1>
    </div>
    <h3>Selamat Datang Kembali</h3>
    <form id="loginForm" method="POST" action="<?php echo e(route('login')); ?>">
      <?php echo csrf_field(); ?>

      <input type="text" id="username" name="username" placeholder="Nama Pengguna" required />
      <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="error-message"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

      <input type="password" id="password" name="password" placeholder="Kata Sandi" required />
      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="error-message"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

      
      <?php if(session('error')): ?>
        <div class="error-message"><?php echo e(session('error')); ?></div>
      <?php endif; ?>

      <button type="submit">Masuk</button>
    </form>

    <p class="auth-link-text">Belum punya akun? <a href="<?php echo e(route('register')); ?>">Daftar</a></p>
  </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\studybuddy\resources\views/auth/login.blade.php ENDPATH**/ ?>